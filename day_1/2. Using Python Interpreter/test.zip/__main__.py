print("kenb;prjt")
